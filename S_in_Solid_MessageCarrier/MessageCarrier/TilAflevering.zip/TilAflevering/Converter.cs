﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MessageCarrier
{
    public class Converter
    {
        public string ConvertBodyToHTML(string plainText)
        {
            return "" + plainText + "";
        }
    }
}
