﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BirdsFlyingAroundApp
{
    public class Penguin : Bird
    {
        public override void SetLocation(double longitude, double latitude)
        {
            //sæt en lokation
        }

        public override void Draw()
        {
            //Tegn fuglen på skærmen
        }
    }
}
