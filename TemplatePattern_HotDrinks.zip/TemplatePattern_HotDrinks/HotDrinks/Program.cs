﻿using System;

namespace HotDrinks
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");


            CupHotDrink coffee = new CupCoffee();

            CupHotDrink tea = new CupTea();


        }
    }
}
